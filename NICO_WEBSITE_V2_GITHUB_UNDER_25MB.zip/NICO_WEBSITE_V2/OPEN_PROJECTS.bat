@echo off
cd /d "%~dp0"
start "" "projects\index.html"
