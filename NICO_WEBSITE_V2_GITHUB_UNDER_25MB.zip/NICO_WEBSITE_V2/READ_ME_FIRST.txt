NICO HOME IMPROVEMENT WEBSITE

WINDOWS:
1. Extract the ZIP completely.
2. Open the extracted NICO_WEBSITE_V2 folder.
3. Double-click START_WEBSITE.bat to open the website.
4. To check the Projects page directly, double-click OPEN_PROJECTS.bat.

Do NOT open files from inside the ZIP archive.

The corrected Projects-page cover images are:
- Bathroom Remodeling: Edgewater bathroom
- Deck & Exterior Projects: Glen Rock deck
- Flooring & Interior Finish: hardwood flooring
- Specialty Projects: garage / home gym
